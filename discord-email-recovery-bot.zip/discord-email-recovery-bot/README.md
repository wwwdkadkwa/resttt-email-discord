# Discord Email Recovery Assistant

A privacy-first Discord slash-command bot that helps users find the email address they used for their own Discord account.

**Important limitation:** Discord does not provide third-party bots with an API to reveal or reset a user's registered email. This bot provides safe guidance and links to official Discord resources. It is not an official Discord product.

## Features

- `/forgot-email` — private step-by-step recovery guidance
- `/check-email` — safe places to check for your login email
- `/support` — official Discord support and login links
- `/help` — commands, privacy information, and limitations
- All replies are ephemeral (visible only to the person who ran the command)
- No email addresses, passwords, 2FA codes, backup codes, or account tokens are requested or stored
- Uses only the `Guilds` intent; no privileged intents are needed

## Requirements

- Windows, macOS, or Linux
- Node.js 18.17.0 or newer
- A Discord account and a server where you can add an app

## 1. Create the Discord application

1. Open https://discord.com/developers/applications
2. Select **New Application** and give it a name, such as `Email Recovery Assistant`.
3. Open **Bot** and select **Add Bot** if Discord shows that option.
4. Under the bot settings, create/reset the bot token and copy it.
5. Keep the token private. Never paste it into Discord, a public website, or a screenshot.

## 2. Invite the bot to your test server

1. In the Developer Portal, open **OAuth2 → URL Generator**.
2. Under Scopes, select `bot` and `applications.commands`.
3. Under Bot Permissions, select `Send Messages` and `Embed Links`.
4. Copy the generated URL, open it, and add the bot to a server where you have permission.

The bot does not need Administrator permission.

## 3. Get your application and server IDs

1. In the Developer Portal, open **General Information** and copy the **Application ID**. This is your `CLIENT_ID`.
2. In Discord, enable **User Settings → Advanced → Developer Mode**.
3. Right-click your test server icon/name and choose **Copy Server ID**. This is your `GUILD_ID`.

## 4. Install and configure on Windows

1. Extract the ZIP file.
2. Install Node.js from https://nodejs.org/ if it is not installed.
3. Open the extracted `discord-email-recovery-bot` folder in File Explorer.
4. Click the address bar, type `cmd`, and press Enter.
5. Run:

   ```bash
   npm install
   ```

6. Make a copy of `.env.example` and name the copy `.env` (make sure it is not named `.env.txt`).
7. Open `.env` in Notepad and fill in the three values:

   ```env
   DISCORD_TOKEN=your_bot_token
   CLIENT_ID=your_application_id
   GUILD_ID=your_test_server_id
   ```

   Do not add quotes. Do not share this file.

## 5. Register the slash commands

In the same Command Prompt window, run:

```bash
npm run deploy
```

You should see: `Done! Commands are registered in your test server.`

## 6. Start the bot

Run:

```bash
npm start
```

Leave this window open while you want the bot online. Open your Discord test server and try `/help`.

## Troubleshooting

- **`npm is not recognized`:** Install Node.js from https://nodejs.org/, close Command Prompt, open it again, and run `node -v` and `npm -v`.
- **Bot is offline:** Check that `.env` contains the correct token, then run `npm start` again.
- **Commands do not appear:** Check `CLIENT_ID` and `GUILD_ID`, make sure the bot is invited with `applications.commands`, then run `npm run deploy` again.
- **Invalid token:** Reset/copy the token in the Developer Portal and update `.env`. Never post the token in chat.
- **Missing permissions:** The bot needs permission to send messages and embed links in the server.

## Privacy and security

This bot intentionally does not ask users to type their email, password, phone number, 2FA code, backup code, or token into a Discord command. Do not add features that collect credentials or claim to discover account emails. Account recovery must happen through Discord's official services.
