const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

const BRAND = 0x5865F2;
const SUPPORT_URL = "https://support.discord.com/hc/en-us/requests/new";
const LOGIN_URL = "https://discord.com/login";
const HELP_URL = "https://support.discord.com/hc/en-us";

function privateEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(BRAND)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: "Email Recovery Assistant • Privacy first" });
}

function supportButtons() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel("Discord Support")
      .setStyle(ButtonStyle.Link)
      .setURL(SUPPORT_URL),
    new ButtonBuilder()
      .setLabel("Discord Login")
      .setStyle(ButtonStyle.Link)
      .setURL(LOGIN_URL)
  );
}

const commands = [
  new SlashCommandBuilder()
    .setName("forgot-email")
    .setDescription("Get safe steps for finding the email on your Discord account."),
  new SlashCommandBuilder()
    .setName("check-email")
    .setDescription("See places you can check to identify your Discord login email."),
  new SlashCommandBuilder()
    .setName("support")
    .setDescription("Open official Discord account-support resources."),
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("See what this recovery assistant can and cannot do.")
].map(command => command.toJSON());

async function handleCommand(interaction) {
  const name = interaction.commandName;

  if (name === "forgot-email") {
    const embed = privateEmbed(
      "Forgot which email you used?",
      [
        "This bot cannot look up, reveal, or reset the email on a Discord account. Only Discord can handle account-specific recovery.",
        "",
        "**Try these safe steps:**",
        "1. Check the inboxes you regularly use and search for messages from **Discord**.",
        "2. Search your email accounts for terms like `Discord`, `verification`, or `security alert`.",
        "3. Check your browser or password manager for a saved Discord login. Do not share saved passwords with anyone.",
        "4. If you previously added a phone number, try the login options Discord provides.",
        "5. If you still cannot identify the email, contact Discord through its official support form.",
        "",
        "⚠️ Never give anyone your password, authentication code, backup codes, or account token."
      ].join("\n")
    );
    return interaction.reply({ embeds: [embed], components: [supportButtons()], ephemeral: true });
  }

  if (name === "check-email") {
    const embed = privateEmbed(
      "Where to check",
      [
        "Use these checks on accounts and devices you own:",
        "",
        "• **Email inboxes:** Search for Discord welcome, verification, billing, or security emails.",
        "• **Password manager:** Look for a saved `discord.com` login; view only the username/email field.",
        "• **Browser autofill:** Check saved login usernames in your own browser settings.",
        "• **Other devices:** If you are still signed in on a device, open Discord's User Settings and review Account information. Discord may ask you to verify before showing or changing details.",
        "",
        "This bot does not collect email addresses or account details."
      ].join("\n")
    );
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (name === "support") {
    const embed = privateEmbed(
      "Official Discord support",
      "For account-specific help, use Discord's official support site. Be cautious of anyone claiming they can reveal your account email or recover your account in exchange for payment."
    );
    return interaction.reply({ embeds: [embed], components: [supportButtons()], ephemeral: true });
  }

  if (name === "help") {
    const embed = privateEmbed(
      "Email Recovery Assistant",
      [
        "**Available commands**",
        "`/forgot-email` — Step-by-step recovery guidance.",
        "`/check-email` — Places to check for your login email.",
        "`/support` — Official Discord support links.",
        "`/help` — This command.",
        "",
        "**Privacy promise**",
        "The bot does not ask for or store email addresses, passwords, 2FA codes, backup codes, or Discord tokens.",
        "",
        "**Important**",
        "This is an independent helper bot, not an official Discord product. It cannot access Discord account records or reset account emails."
      ].join("\n")
    );
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
}

module.exports = { commands, handleCommand };
